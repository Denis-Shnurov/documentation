Для работы программы требуется .NET 8 Runtime.  
Скачать: https://dotnet.microsoft.com/download/dotnet/8.0  